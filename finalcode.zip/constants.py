import os

# face_data (directory) represents the path component to be joined.

FACE_DATA_PATH = os.path.join(os.getcwd(),'face_cluster')
ENCODINGS_PATH = os.path.join(os.getcwd(),'encodings.pickle')
CLUSTERING_RESULT_PATH = os.getcwd()